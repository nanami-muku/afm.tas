function onBegin()
    disableMovement()
    say("Lbounce")
    jump()
    walkTo(2144, true, 10.0, false)
    wait(1)
    jump()
    walkTo(-3294, false, 1.0, false)	
    say("Commf")
    enableMovement()
end

function onEnd(level, wasSkipped)
    if wasSkipped then
        teleportTo(-3933, -1828)
        enableMovement()
    end
end