function onBegin()
    disableMovement()
    say("Cut1")
    jump()
    walkTo(500, false, 1.0, false)
    wait(1)
    walkTo(499, false, 1.0, false)
    wait(1)
    walkTo(498, false, 1.0, false)		
    say("Cut2")
    enableMovement()
end

function onEnd(level, wasSkipped)
    if wasSkipped then
        teleportTo(499, -3693)
        enableMovement()
    end
end