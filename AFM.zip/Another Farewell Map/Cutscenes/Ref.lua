function onBegin()
    disableMovement()
    say("Cut1")
    jump() 
    walkTo(500, false, 1.0, false
    say("Cut2")
    enableMovement()
end

function onEnd(level, wasSkipped)
    if wasSkipped then
        teleportTo(500, -3693)
        enableMovement()
    end
end